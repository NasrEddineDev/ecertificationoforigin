<?php

namespace App\Enums;

abstract class Gender
{
    public const MALE = 1;
    public const FEMALE = 0;
}