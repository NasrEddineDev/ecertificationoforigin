<?php

namespace App\Enums;

abstract class ExporterTypes
{
    public const cash = 0;
    public const ccp = 1;
    public const dhahabia = 2;
    public const cib = 3;
    public const OTHER = 4;
}