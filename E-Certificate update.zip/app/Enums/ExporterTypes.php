<?php

namespace App\Enums;

abstract class ExporterTypes
{
    public const Trader = 0;
    public const Craftsman = 1;
    public const Farmer = 2;
    public const OTHER = 3;
}