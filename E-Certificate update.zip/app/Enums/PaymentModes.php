<?php

namespace App\Enums;

abstract class ExporterTypes
{
    public const credit = 0;
    public const debit = 1;
}