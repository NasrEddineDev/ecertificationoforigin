<div class="footer-copyright-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-copy-right">
                    <p>{{__('Copyright © 2021. All rights reserved. Algerian Chamber of Commerce and Industry')}} <a href="https://caci.dz">CACI</a></p>
                </div>
            </div>
        </div>
    </div>
</div>